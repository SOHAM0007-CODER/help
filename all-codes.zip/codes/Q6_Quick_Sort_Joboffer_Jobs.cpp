#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

#define MAX_RECORDS 1000000

struct Job
{
    string jobID;
    string title;
    string company;
    long long salary;
    string postingDate;
    double companyRating;
};

Job *arr = new Job[MAX_RECORDS];
int n = 0;
int choice;

// Compare records using the field selected by the user.
bool isSmaller(const Job &a, const Job &b)
{
    if (choice == 1)
        return a.salary < b.salary;
    if (choice == 2)
        return a.postingDate < b.postingDate;
    return a.companyRating < b.companyRating;
}

// Quick Sort - ascending order, using the middle record as pivot.
void quickSort(int low, int high)
{
    if (low >= high)
        return;

    int i = low;
    int j = high;
    Job pivot = arr[low + (high - low) / 2];

    while (i <= j)
    {
        while (i <= high && isSmaller(arr[i], pivot))
            i++;

        while (j >= low && isSmaller(pivot, arr[j]))
            j--;

        if (i <= j)
        {
            Job temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            i++;
            j--;
        }
    }

    if (low < j)
        quickSort(low, j);

    if (i < high)
        quickSort(i, high);
}

int main()
{
    ifstream file("C:/Users/soham/Downloads/DAA DATASET/06_joboffer_jobs.csv");

    if (!file)
    {
        cout << "File not found!\n";
        delete[] arr;
        return 1;
    }

    string line;
    getline(file, line); // Skip header.

    while (n < MAX_RECORDS && getline(file, line))
    {
        if (!line.empty() && line.back() == '\r')
            line.pop_back();
        if (line.empty())
            continue;

        stringstream ss(line);
        string value;

        getline(ss, arr[n].jobID, ',');
        getline(ss, arr[n].title, ',');
        getline(ss, arr[n].company, ',');
        getline(ss, value, ',');
        arr[n].salary = stoll(value);
        getline(ss, arr[n].postingDate, ',');
        getline(ss, value);
        arr[n].companyRating = stod(value);

        n++;
    }

    file.close();

    cout << "Sort by:\n";
    cout << "1. Salary\n";
    cout << "2. Posting Date\n";
    cout << "3. Company Rating\n";
    cout << "Enter choice: ";
    if (!(cin >> choice) || choice < 1 || choice > 3)
    {
        cout << "Invalid choice!\n";
        delete[] arr;
        return 1;
    }

    quickSort(0, n - 1);

    cout << "\nSorted Records - Ascending Order\n\n";
    cout << "jobID\ttitle\tcompany\tsalary\tpostingDate\tcompanyRating\n";

    for (int i = 0; i < n && i < 30; i++)
    {
        cout << arr[i].jobID << "\t"
             << arr[i].title << "\t"
             << arr[i].company << "\t"
             << arr[i].salary << "\t"
             << arr[i].postingDate << "\t"
             << arr[i].companyRating << "\n";
    }

    delete[] arr;
    return 0;
}
