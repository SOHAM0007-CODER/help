#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

#define MAX_RECORDS 1000000

struct Product
{
    string productID;
    string name;
    string category;
    double price;
    double rating;
    long long unitsSold;
};

Product *arr = new Product[MAX_RECORDS];
int n = 0;
int choice;

// Compare records using the field selected by the user.
bool isSmaller(const Product &a, const Product &b)
{
    if (choice == 1)
        return a.price < b.price;
    if (choice == 2)
        return a.rating < b.rating;
    return a.unitsSold < b.unitsSold;
}

// Quick Sort - ascending order, using the middle record as pivot.
void quickSort(int low, int high)
{
    if (low >= high)
        return;

    int i = low;
    int j = high;
    Product pivot = arr[low + (high - low) / 2];

    while (i <= j)
    {
        while (i <= high && isSmaller(arr[i], pivot))
            i++;

        while (j >= low && isSmaller(pivot, arr[j]))
            j--;

        if (i <= j)
        {
            Product temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            i++;
            j--;
        }
    }

    if (low < j)
        quickSort(low, j);

    if (i < high)
        quickSort(i, high);
}

int main()
{
    ifstream file("C:/Users/soham/Downloads/DAA DATASET/05_shoppy_products.csv");

    if (!file)
    {
        cout << "File not found!\n";
        delete[] arr;
        return 1;
    }

    string line;
    getline(file, line); // Skip header.

    while (n < MAX_RECORDS && getline(file, line))
    {
        if (!line.empty() && line.back() == '\r')
            line.pop_back();
        if (line.empty())
            continue;

        stringstream ss(line);
        string value;

        getline(ss, arr[n].productID, ',');
        getline(ss, arr[n].name, ',');
        getline(ss, arr[n].category, ',');
        getline(ss, value, ',');
        arr[n].price = stod(value);
        getline(ss, value, ',');
        arr[n].rating = stod(value);
        getline(ss, value);
        arr[n].unitsSold = stoll(value);

        n++;
    }

    file.close();

    cout << "Sort by:\n";
    cout << "1. Price\n";
    cout << "2. Rating\n";
    cout << "3. Sales Volume\n";
    cout << "Enter choice: ";
    if (!(cin >> choice) || choice < 1 || choice > 3)
    {
        cout << "Invalid choice!\n";
        delete[] arr;
        return 1;
    }

    quickSort(0, n - 1);

    cout << "\nSorted Records - Ascending Order\n\n";
    cout << "productID\tname\tcategory\tprice\trating\tunitsSold\n";

    for (int i = 0; i < n && i < 30; i++)
    {
        cout << arr[i].productID << "\t"
             << arr[i].name << "\t"
             << arr[i].category << "\t"
             << arr[i].price << "\t"
             << arr[i].rating << "\t"
             << arr[i].unitsSold << "\n";
    }

    delete[] arr;
    return 0;
}
