#include <algorithm>
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

struct Item
{
    string name;
    double weight, value, ratio;
    bool divisible;
};

int main()
{
    Item items[100];
    int n;
    double capacity;

    cout << "Enter number of advertisement requests (1-100): ";
    if (!(cin >> n) || n < 1 || n > 100)
    {
        cout << "Invalid number of advertisements!\n";
        return 1;
    }

    for (int i = 0; i < n; i++)
    {
        int choice;
        cout << "\nAdvertisement " << i + 1 << "\n";
        cout << "Advertisement name: ";
        getline(cin >> ws, items[i].name);
        cout << "Duration (minutes), revenue, divisible (1/0): ";

        if (!(cin >> items[i].weight >> items[i].value >> choice)
            || items[i].weight <= 0 || items[i].value < 0
            || (choice != 0 && choice != 1))
        {
            cout << "Invalid advertisement details!\n";
            return 1;
        }

        items[i].divisible = (choice == 1);
        items[i].ratio = items[i].value / items[i].weight;
    }

    cout << "\nEnter available advertisement time (minutes): ";
    if (!(cin >> capacity) || capacity < 0)
    {
        cout << "Invalid capacity!\n";
        return 1;
    }

    cout << "\nENTERED ADVERTISEMENT DETAILS\n";
    cout << left << setw(22) << "Advertisement"
         << setw(12) << "Duration" << setw(12) << "Revenue"
         << setw(12) << "Ratio" << "Divisible\n";
    cout << string(70, '-') << "\n";

    for (int i = 0; i < n; i++)
    {
        cout << setw(22) << items[i].name
             << setw(12) << items[i].weight
             << setw(12) << items[i].value
             << setw(12) << items[i].ratio
             << (items[i].divisible ? "Yes" : "No") << "\n";
    }

    // Sort by descending revenue-to-duration ratio.
    std::sort(items, items + n, [](const Item& a, const Item& b) {
        return a.ratio > b.ratio;
    });

    double remaining = capacity;
    double totalValue = 0;

    cout << "\nADVERTISEMENT SLOT ALLOCATION (RATIO ORDER)\n";
    cout << setw(22) << "Advertisement" << setw(10) << "Ratio"
         << setw(12) << "Total Time" << setw(12) << "Taken Time"
         << setw(12) << "Revenue" << setw(12) << "Gained"
         << setw(12) << "Fraction" << "Status\n";
    cout << string(110, '-') << "\n";

    // Greedy selection: optimal for the standard all-divisible problem.
    // With mixed divisible/indivisible items, this is a heuristic.
    for (int i = 0; i < n; i++)
    {
        double taken = 0;
        string status = "Skipped";

        if (remaining <= 0)
            status = "No time left";
        else if (items[i].weight <= remaining)
        {
            taken = items[i].weight;
            status = "Full ad";
        }
        else if (items[i].divisible)
        {
            taken = remaining;
            status = "Partial ad";
        }

        double fraction = taken / items[i].weight;
        double gained = fraction * items[i].value;
        remaining -= taken;
        totalValue += gained;

        cout << setw(22) << items[i].name
             << setw(10) << items[i].ratio
             << setw(12) << items[i].weight
             << setw(12) << taken
             << setw(12) << items[i].value
             << setw(12) << gained
             << setw(12) << fraction << status << "\n";
    }

    cout << "\nAvailable Ad Time      : " << capacity << " minutes\n";
    cout << "Total Time Allocated   : " << capacity - remaining << " minutes\n";
    cout << "Unused Ad Time         : " << remaining << " minutes\n";
    cout << "Total Revenue Obtained : " << totalValue << "\n";
    return 0;
}
