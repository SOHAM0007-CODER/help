#include <algorithm>
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

struct Item
{
    string name;
    double weight, value, ratio;
    bool divisible;
};

int main()
{
    Item items[100];
    int n;
    double capacity;

    cout << "Enter number of EV charging requests (1-100): ";
    if (!(cin >> n) || n < 1 || n > 100)
    {
        cout << "Invalid number of charging requests!\n";
        return 1;
    }

    for (int i = 0; i < n; i++)
    {
        int choice;
        cout << "\nEV request " << i + 1 << "\n";
        cout << "Vehicle name/ID: ";
        getline(cin >> ws, items[i].name);
        cout << "Energy required (kWh), benefit value, divisible (1/0): ";

        if (!(cin >> items[i].weight >> items[i].value >> choice)
            || items[i].weight <= 0 || items[i].value < 0
            || (choice != 0 && choice != 1))
        {
            cout << "Invalid charging request details!\n";
            return 1;
        }

        items[i].divisible = (choice == 1);
        items[i].ratio = items[i].value / items[i].weight;
    }

    cout << "\nEnter available energy (kWh): ";
    if (!(cin >> capacity) || capacity < 0)
    {
        cout << "Invalid capacity!\n";
        return 1;
    }

    cout << "\nENTERED EV CHARGING REQUESTS\n";
    cout << left << setw(22) << "Vehicle Name/ID"
         << setw(12) << "Energy" << setw(12) << "Benefit"
         << setw(12) << "Ratio" << "Divisible\n";
    cout << string(70, '-') << "\n";

    for (int i = 0; i < n; i++)
    {
        cout << setw(22) << items[i].name
             << setw(12) << items[i].weight
             << setw(12) << items[i].value
             << setw(12) << items[i].ratio
             << (items[i].divisible ? "Yes" : "No") << "\n";
    }

    // Sort by descending benefit-to-energy ratio.
    std::sort(items, items + n, [](const Item& a, const Item& b) {
        return a.ratio > b.ratio;
    });

    double remaining = capacity;
    double totalValue = 0;

    cout << "\nEV CHARGING ALLOCATION (RATIO ORDER)\n";
    cout << setw(22) << "Vehicle Name/ID" << setw(10) << "Ratio"
         << setw(12) << "Req. Energy" << setw(12) << "Allocated"
         << setw(12) << "Benefit" << setw(12) << "Gained"
         << setw(12) << "Fraction" << "Status\n";
    cout << string(110, '-') << "\n";

    // Greedy selection: optimal for the standard all-divisible problem.
    // With mixed divisible/indivisible items, this is a heuristic.
    for (int i = 0; i < n; i++)
    {
        double taken = 0;
        string status = "Skipped";

        if (remaining <= 0)
            status = "No energy left";
        else if (items[i].weight <= remaining)
        {
            taken = items[i].weight;
            status = "Full charging";
        }
        else if (items[i].divisible)
        {
            taken = remaining;
            status = "Partial charging";
        }

        double fraction = taken / items[i].weight;
        double gained = fraction * items[i].value;
        remaining -= taken;
        totalValue += gained;

        cout << setw(22) << items[i].name
             << setw(10) << items[i].ratio
             << setw(12) << items[i].weight
             << setw(12) << taken
             << setw(12) << items[i].value
             << setw(12) << gained
             << setw(12) << fraction << status << "\n";
    }

    cout << "\nAvailable Energy       : " << capacity << " kWh\n";
    cout << "Total Energy Allocated : " << capacity - remaining << " kWh\n";
    cout << "Unused Energy          : " << remaining << " kWh\n";
    cout << "Total Benefit Obtained : " << totalValue << "\n";
    return 0;
}
