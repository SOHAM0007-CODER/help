
#include <iostream>
#include <string>
using namespace std;

int graph[20][20];
int color[20];
string tower[20];

string colors[] = {
    "Red", "Blue", "Green", "Yellow", "Orange", "Purple", "Pink", "Brown", "White", "Black", "Gray", "Violet"
};

int n;

// Check whether a frequency can be assigned
bool isSafe(int node, int c)
{
    for(int i = 0; i < n; i++)
    {
        if(graph[node][i] == 1 && color[i] == c)
            return false;
    }

    return true;
}

// Graph Coloring using Backtracking
bool graphColoring(int node, int m)
{
    // All towers are assigned frequencies
    if(node == n)
        return true;

    // Try available colors
    for(int c = 1; c <= m; c++)
    {
        if(isSafe(node, c))
        {
            color[node] = c;

            if(graphColoring(node + 1, m))
                return true;

            // Backtracking
            color[node] = 0;
        }
    }

    return false;
}

int main()
{
    int e;

    cout << "INTERFERENCE-FREE FREQUENCY ALLOCATION\n";

    cout << "\nEnter number of wireless towers: ";
    cin >> n;

    if(n < 1 || n > 20)
    {
        cout << "Invalid number of towers!";
        return 0;
    }

    // Initialize graph and colors
    for(int i = 0; i < n; i++)
    {
        color[i] = 0;

        for(int j = 0; j < n; j++)
            graph[i][j] = 0;
    }

    // Input tower names
    cout << "\nEnter tower names:\n";

    for(int i = 0; i < n; i++)
    {
        cout << "Tower " << i + 1 << ": ";
        cin >> tower[i];
    }

    // Input interference pairs
    cout << "\nEnter number of interfering tower pairs: ";
    cin >> e;

    if(e < 0 || e > n * (n - 1) / 2)
    {
        cout << "Invalid number of interference pairs!";
        return 0;
    }

    cout << "\nEnter interfering tower pairs:\n";

    for(int i = 0; i < e; i++)
    {
        int u, v;
        cin >> u >> v;

        if(u < 1 || u > n || v < 1 || v > n || u == v)
        {
            cout << "Invalid tower IDs!";
            return 0;
        }

        // Convert to 0-based indexing
        u--;
        v--;

        graph[u][v] = 1;
        graph[v][u] = 1;
    }

    // Display interference table
    cout << "\nINTERFERENCE TABLE\n";
    cout << "Tower | Interfering towers\n";

    for(int i = 0; i < n; i++)
    {
        cout << tower[i] << " | ";

        for(int j = 0; j < n; j++)
        {
            if(graph[i][j] == 1)
                cout << tower[j] << " ";
        }

        cout << endl;
    }

    // Find minimum number of frequencies
    int m;

    for(m = 1; m <= n; m++)
    {
        for(int i = 0; i < n; i++)
            color[i] = 0;

        if(graphColoring(0, m))
            break;
    }

    // Display frequency assignment
    cout << "\nFREQUENCY CHANNEL ASSIGNMENT\n";
    cout << "Tower | Assigned Frequency\n";

    for(int i = 0; i < n; i++)
    {
        cout << tower[i] << " | Channel "
             << color[i] << " (" << colors[color[i] - 1] << ")\n";
    }

    // Display towers grouped by frequency
    cout << "\nTOWERS GROUPED BY FREQUENCY\n";

    for(int c = 1; c <= m; c++)
    {
        cout << "Channel " << c << " ("
             << colors[c - 1] << "): ";

        for(int i = 0; i < n; i++)
        {
            if(color[i] == c)
                cout << tower[i] << " ";
        }

        cout << endl;
    }

    // Scheduling summary
    cout << "\nFREQUENCY ALLOCATION SUMMARY\n";
    cout << "Total Towers: " << n << endl;
    cout << "Total Interference Pairs: " << e << endl;
    cout << "Minimum Channels Used: " << m << endl;

    return 0;
}

