#include <iostream>
#include <climits>
using namespace std;

int graph[101][101], dist[101], visited[101], parent[101];

// Dijkstra Algorithm
void dijkstra(int n, int source)
{
    for(int i = 0; i < n; i++)
    {
        dist[i] = INT_MAX;
        visited[i] = 0;
        parent[i] = -1;
    }

    dist[source] = 0;

    for(int i = 0; i < n - 1; i++)
    {
        int u = -1;

        for(int j = 0; j < n; j++)
            if(!visited[j] && (u == -1 || dist[j] < dist[u]))
                u = j;

        if(u == -1 || dist[u] == INT_MAX)
            break;

        visited[u] = 1;

        for(int v = 0; v < n; v++)
        {
            if(graph[u][v] > 0 && !visited[v] &&
               dist[u] + graph[u][v] < dist[v])
            {
                dist[v] = dist[u] + graph[u][v];
                parent[v] = u;
            }
        }
    }
}

// Display shortest path
void display(int destination)
{
    if(dist[destination] == INT_MAX)
    {
        cout << "\nDestination is not reachable!\n";
        return;
    }

    cout << "\nDestination Hospital: " << destination;
    cout << "\nShortest Travel Time: " << dist[destination] << " minutes";

    int path[101], count = 0;

    for(int v = destination; v != -1; v = parent[v])
        path[count++] = v;

    cout << "\nShortest Route: ";

    for(int i = count - 1; i >= 0; i--)
    {
        cout << path[i];
        if(i > 0)
            cout << " -> ";
    }

    cout << endl;
}

int main()
{
    int n, e;

    cout << "Enter number of intersections: ";
    cin >> n;

    if(cin.fail() || n <= 0 || n > 100)
    {
        cout << "Invalid number of intersections!";
        return 1;
    }

    cout << "Enter number of roads: ";
    cin >> e;

    if(cin.fail() || e < 0 || e > 10000)
    {
        cout << "Invalid number of roads!";
        return 1;
    }

    cout << "\nEnter roads (Source Destination TravelTime):\n";

    for(int i = 0; i < e; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;

        if(cin.fail() || u < 0 || u >= n ||
           v < 0 || v >= n || u == v || w <= 0)
        {
            cout << "Invalid road details!";
            return 1;
        }

        graph[u][v] = graph[v][u] = w;
    }

    int source, destination;

    cout << "\nEnter ambulance starting location: ";
    cin >> source;

    if(cin.fail() || source < 0 || source >= n)
    {
        cout << "Invalid starting location!";
        return 1;
    }

    cout << "Enter final destination (Hospital): ";
    cin >> destination;

    if(cin.fail() || destination < 0 || destination >= n ||
       destination == source)
    {
        cout << "Invalid hospital location!";
        return 1;
    }

    // Before traffic update
    dijkstra(n, source);

    cout << "\nBEFORE TRAFFIC UPDATE :\n";
    display(destination);

    // Ask for traffic update
    char choice;

    cout << "\nDo you want to change road travel time? (Y/N): ";
    cin >> choice;

    if(choice == 'Y' || choice == 'y')
    {
        int u, v, newTime;

        cout << "Enter affected road (Source Destination): ";
        cin >> u >> v;

        if(cin.fail() || u < 0 || u >= n ||
           v < 0 || v >= n || graph[u][v] == 0)
        {
            cout << "Invalid road!";
            return 1;
        }

        cout << "Enter new travel time: ";
        cin >> newTime;

        if(cin.fail() || newTime <= 0)
        {
            cout << "Invalid travel time!";
            return 1;
        }

        graph[u][v] = graph[v][u] = newTime;

        // After traffic update
        dijkstra(n, source);

        cout << "\nAFTER TRAFFIC UPDATE :\n";
        display(destination);
    }
    else if(choice == 'N' || choice == 'n')
    {
        cout << "\nNo traffic update required.\n";
    }
    else
    {
        cout << "Invalid choice!";
    }

    return 0;
}
