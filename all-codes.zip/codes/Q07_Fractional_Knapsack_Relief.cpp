#include <algorithm>
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

struct Item
{
    string name;
    double weight, value, ratio;
    bool divisible;
};

int main()
{
    Item items[100];
    int n;
    double capacity;

    cout << "Enter number of relief items (1-100): ";
    if (!(cin >> n) || n < 1 || n > 100)
    {
        cout << "Invalid number of items!\n";
        return 1;
    }

    for (int i = 0; i < n; i++)
    {
        int choice;
        cout << "\nItem " << i + 1 << "\n";
        cout << "Name: ";
        getline(cin >> ws, items[i].name);
        cout << "Weight (kg), utility value, divisible (1/0): ";

        if (!(cin >> items[i].weight >> items[i].value >> choice)
            || items[i].weight <= 0 || items[i].value < 0
            || (choice != 0 && choice != 1))
        {
            cout << "Invalid item details!\n";
            return 1;
        }

        items[i].divisible = (choice == 1);
        items[i].ratio = items[i].value / items[i].weight;
    }

    cout << "\nEnter boat capacity (kg): ";
    if (!(cin >> capacity) || capacity < 0)
    {
        cout << "Invalid capacity!\n";
        return 1;
    }

    cout << "\nENTERED ITEM DETAILS\n";
    cout << left << setw(22) << "Item Name"
         << setw(12) << "Weight" << setw(12) << "Value"
         << setw(12) << "Ratio" << "Divisible\n";
  

    for (int i = 0; i < n; i++)
    {
        cout << setw(22) << items[i].name
             << setw(12) << items[i].weight
             << setw(12) << items[i].value
             << setw(12) << items[i].ratio
             << (items[i].divisible ? "Yes" : "No") << "\n";
    }

    // Sort by descending utility-to-weight ratio.
    std::sort(items, items + n, [](const Item& a, const Item& b) {
        return a.ratio > b.ratio;
    });

    double remaining = capacity;
    double totalValue = 0;

    cout << "\nRELIEF SUPPLY SELECTION (RATIO ORDER)\n";
    cout << setw(22) << "Item Name" << setw(10) << "Ratio"
         << setw(12) << "Total Wt." << setw(12) << "Taken Wt."
         << setw(12) << "Total Value" << setw(12) << "Gained"
         << setw(12) << "Fraction" << "Status\n";
    

    // Greedy selection: optimal for the standard all-divisible problem.
    // With mixed divisible/indivisible items, this is a heuristic.
    for (int i = 0; i < n; i++)
    {
        double taken = 0;
        string status = "Skipped";

        if (remaining <= 0)
            status = "No capacity left";
        else if (items[i].weight <= remaining)
        {
            taken = items[i].weight;
            status = "Full item";
        }
        else if (items[i].divisible)
        {
            taken = remaining;
            status = "Partial item";
        }

        double fraction = taken / items[i].weight;
        double gained = fraction * items[i].value;
        remaining -= taken;
        totalValue += gained;

        cout << setw(22) << items[i].name
             << setw(10) << items[i].ratio
             << setw(12) << items[i].weight
             << setw(12) << taken
             << setw(12) << items[i].value
             << setw(12) << gained
             << setw(12) << fraction << status << "\n";
    }

    cout << "\nBoat Capacity          : " << capacity << " kg\n";
    cout << "Total Weight Used      : " << capacity - remaining << " kg\n";
    cout << "Unused Capacity        : " << remaining << " kg\n";
    cout << "Total Utility Obtained : " << totalValue << "\n";
    return 0;
}
