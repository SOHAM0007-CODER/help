#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

#define MAX_ORDERS 1000000

struct Order
{
    string orderID;
    string customerID;
    string timestamp;
    double amount;
};

Order *arr = new Order[MAX_ORDERS];
Order *temp = new Order[MAX_ORDERS];
int n = 0;

// Merge Function - ascending order; equal keys keep their original order.
void merge(int low, int mid, int high)
{
    int i = low;
    int j = mid + 1;
    int k = low;

    while (i <= mid && j <= high)
    {
        if (arr[i].timestamp <= arr[j].timestamp)
            temp[k++] = arr[i++];
        else
            temp[k++] = arr[j++];
    }

    while (i <= mid)
        temp[k++] = arr[i++];

    while (j <= high)
        temp[k++] = arr[j++];

    for (i = low; i <= high; i++)
        arr[i] = temp[i];
}

// Merge Sort - same algorithm as your original code.
void mergeSort(int low, int high)
{
    if (low < high)
    {
        int mid = low + (high - low) / 2;
        mergeSort(low, mid);
        mergeSort(mid + 1, high);
        merge(low, mid, high);
    }
}

int main()
{

    ifstream file("01_customer_orders.csv");

    if (!file)
    {
        cout << "File not found!\n";
        delete[] arr;
        delete[] temp;
        return 1;
    }

    string line;
    getline(file, line); // Skip header.

    while (n < MAX_ORDERS && getline(file, line))
    {
        if (!line.empty() && line.back() == '\r')
            line.pop_back();
        if (line.empty())
            continue;

        stringstream ss(line);
        string value;

        getline(ss, arr[n].orderID, ',');
        getline(ss, arr[n].customerID, ',');
        getline(ss, arr[n].timestamp, ',');
        getline(ss, value);
        arr[n].amount = stod(value);

        n++;
    }

    file.close();
    mergeSort(0, n - 1);

    cout << "\nCustomer Orders Sorted by Purchase Timestamp\n\n";
    cout << "orderID\tcustomerID\ttimestamp\tamount\n";


    for (int i = 0; i < n && i < 30; i++)
    {
        cout << arr[i].orderID << "\t"
             << arr[i].customerID << "\t"
             << arr[i].timestamp << "\t"
             << arr[i].amount << "\n";
    }

    delete[] arr;
    delete[] temp;
    return 0;
}
