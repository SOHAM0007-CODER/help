#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

#define MAX_ORDERS 1000000

struct Book
{
    string bookID;
    string userID;
    string category;
    string borrowDate;
    string returnDeadline;
};

Book *arr = new Book[MAX_ORDERS];
Book *temp = new Book[MAX_ORDERS];
int n = 0;

// Merge Function - ascending order; equal keys keep their original order.
void merge(int low, int mid, int high)
{
    int i = low;
    int j = mid + 1;
    int k = low;

    while (i <= mid && j <= high)
    {
        if (arr[i].returnDeadline <= arr[j].returnDeadline)
            temp[k++] = arr[i++];
        else
            temp[k++] = arr[j++];
    }

    while (i <= mid)
        temp[k++] = arr[i++];

    while (j <= high)
        temp[k++] = arr[j++];

    for (i = low; i <= high; i++)
        arr[i] = temp[i];
}

// Merge Sort - same algorithm as your original code.
void mergeSort(int low, int high)
{
    if (low < high)
    {
        int mid = low + (high - low) / 2;
        mergeSort(low, mid);
        mergeSort(mid + 1, high);
        merge(low, mid, high);
    }
}

int main()
{
    
    ifstream file("C:/Users/soham/Downloads/DAA DATASET/03_library_books.csv");

    if (!file)
    {
        cout << "File not found!\n";
        delete[] arr;
        delete[] temp;
        return 1;
    }

    string line;
    getline(file, line); // Skip header.

    while (n < MAX_ORDERS && getline(file, line))
    {
        if (!line.empty() && line.back() == '\r')
            line.pop_back();
        if (line.empty())
            continue;

        stringstream ss(line);
        string value;

        getline(ss, arr[n].bookID, ',');
        getline(ss, arr[n].userID, ',');
        getline(ss, arr[n].category, ',');
        getline(ss, arr[n].borrowDate, ',');
        getline(ss, arr[n].returnDeadline);

        n++;
    }

    file.close();
    mergeSort(0, n - 1);

    cout << "\nLibrary Books Sorted by Return Deadline\n\n";
    cout << "bookID\tuserID\tcategory\tborrowDate\treturnDeadline\n";
   

    for (int i = 0; i < n && i < 30; i++)
    {
        cout << arr[i].bookID << "\t"
             << arr[i].userID << "\t"
             << arr[i].category << "\t"
             << arr[i].borrowDate << "\t"
             << arr[i].returnDeadline << "\n";
    }

    delete[] arr;
    delete[] temp;
    return 0;
}
