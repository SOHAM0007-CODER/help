#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

#define MAX_RECORDS 1000000

struct Movie
{
    string movieID;
    string title;
    string genre;
    double rating;
    int releaseYear;
    long long watchHours;
};

Movie *arr = new Movie[MAX_RECORDS];
int n = 0;
int choice;

// Compare records using the field selected by the user.
bool isSmaller(const Movie &a, const Movie &b)
{
    if (choice == 1)
        return a.rating < b.rating;
    if (choice == 2)
        return a.releaseYear < b.releaseYear;
    return a.watchHours < b.watchHours;
}

// Quick Sort - ascending order, using the middle record as pivot.
void quickSort(int low, int high)
{
    if (low >= high)
        return;

    int i = low;
    int j = high;
    Movie pivot = arr[low + (high - low) / 2];

    while (i <= j)
    {
        while (i <= high && isSmaller(arr[i], pivot))
            i++;

        while (j >= low && isSmaller(pivot, arr[j]))
            j--;

        if (i <= j)
        {
            Movie temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            i++;
            j--;
        }
    }

    if (low < j)
        quickSort(low, j);

    if (i < high)
        quickSort(i, high);
}

int main()
{
    ifstream file("04_streamflix_movies.csv");

    if (!file)
    {
        cout << "File not found!\n";
        delete[] arr;
        return 1;
    }

    string line;
    getline(file, line); // Skip header.

    while (n < MAX_RECORDS && getline(file, line))
    {
        if (!line.empty() && line.back() == '\r')
            line.pop_back();
        if (line.empty())
            continue;

        stringstream ss(line);
        string value;

        getline(ss, arr[n].movieID, ',');
        getline(ss, arr[n].title, ',');
        getline(ss, arr[n].genre, ',');
        getline(ss, value, ',');
        arr[n].rating = stod(value);
        getline(ss, value, ',');
        arr[n].releaseYear = stoi(value);
        getline(ss, value);
        arr[n].watchHours = stoll(value);

        n++;
    }

    file.close();

    cout << "Sort by:\n";
    cout << "1. IMDB Rating\n";
    cout << "2. Release Year\n";
    cout << "3. Watch Hours\n";
    cout << "Enter choice: ";
    if (!(cin >> choice) || choice < 1 || choice > 3)
    {
        cout << "Invalid choice!\n";
        delete[] arr;
        return 1;
    }

    quickSort(0, n - 1);

    cout << "\nSorted Records - Ascending Order\n\n";
    cout << "movieID\ttitle\tgenre\trating\treleaseYear\twatchHours\n";

    for (int i = 0; i < n && i < 30; i++)
    {
        cout << arr[i].movieID << "\t"
             << arr[i].title << "\t"
             << arr[i].genre << "\t"
             << arr[i].rating << "\t"
             << arr[i].releaseYear << "\t"
             << arr[i].watchHours << "\n";
    }

    delete[] arr;
    return 0;
}
