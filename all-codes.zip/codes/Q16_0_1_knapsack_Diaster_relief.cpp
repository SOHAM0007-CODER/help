
#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

struct Item
{
    string name;
    int weight, utility;
    bool selected;
};

int main()
{
    int N, W;

    cout << "DISASTER RELIEF RESOURCE ALLOCATION\n";

    cout << "Enter number of relief items: ";
    cin >> N;

    if (!cin || N <= 0)
    {
        cout << "Invalid number of items.\n";
        return 0;
    }

    vector<Item> items(N);

    cout << "\nEnter item details: Name Weight Utility\n";

    for (int i = 0; i < N; i++)
    {
        cout << "Item " << i + 1 << ": ";

        cin >> items[i].name
            >> items[i].weight
            >> items[i].utility;

        if (!cin || items[i].weight <= 0 ||
            items[i].utility < 0)
        {
            cout << "Invalid item details.\n";
            return 0;
        }

        items[i].selected = false;
    }

    // Display inventory
    cout << "\nRELIEF ITEM INVENTORY:\n";

    cout << left << setw(15) << "Item"
         << setw(15) << "Weight (kg)"
         << setw(15) << "Utility" << "\n";

    for (int i = 0; i < N; i++)
    {
        cout << left << setw(15) << items[i].name
             << setw(15) << items[i].weight
             << setw(15) << items[i].utility << "\n";
    }

    cout << "\nEnter truck capacity (kg): ";
    cin >> W;

    if (!cin || W < 0)
    {
        cout << "Invalid truck capacity.\n";
        return 0;
    }

    // Dynamic Programming table
    vector<vector<int> > dp(
        N + 1, vector<int>(W + 1, 0)
    );

    for (int i = 1; i <= N; i++)
    {
        for (int w = 0; w <= W; w++)
        {
            // Exclude the current item
            dp[i][w] = dp[i - 1][w];

            // Include the current item if capacity allows
            if (items[i - 1].weight <= w)
            {
                int newUtility =
                    items[i - 1].utility +
                    dp[i - 1][w - items[i - 1].weight];

                if (newUtility > dp[i][w])
                {
                    dp[i][w] = newUtility;
                }
            }
        }
    }

    // Backtracking to find selected items
    int remainingCapacity = W;

    for (int i = N; i >= 1; i--)
    {
        if (dp[i][remainingCapacity] !=
            dp[i - 1][remainingCapacity])
        {
            items[i - 1].selected = true;

            remainingCapacity -= items[i - 1].weight;
        }
    }

    // Display selected items
    int totalWeight = 0;
    int totalUtility = 0;
    int count = 0;

    cout << "\nSELECTED RELIEF ITEMS:\n";

    cout << left << setw(15) << "Item"
         << setw(15) << "Weight (kg)"
         << setw(15) << "Utility" << "\n";

    for (int i = 0; i < N; i++)
    {
        if (items[i].selected)
        {
            cout << left << setw(15) << items[i].name
                 << setw(15) << items[i].weight
                 << setw(15) << items[i].utility << "\n";

            totalWeight += items[i].weight;
            totalUtility += items[i].utility;
            count++;
        }
    }

    if (count == 0)
        cout << "No items selected.\n";

    // Final allocation summary
    cout << "\nFINAL ALLOCATION SUMMARY:\n";

    cout << "Truck Capacity      : " << W << " kg\n";
    cout << "Total Weight Loaded : " << totalWeight << " kg\n";
    cout << "Remaining Capacity  : "
         << W - totalWeight << " kg\n";
    cout << "Items Selected      : " << count << "\n";
    cout << "Maximum Utility     : " << dp[N][W] << "\n";

    cout << "\nREMAINING ITEMS:\n";

    for (int i = 0; i < N; i++)
    {
        if (!items[i].selected)
        {
            cout << items[i].name
                 << " - " << items[i].weight
                 << " kg, Utility: " << items[i].utility
                 << "\n";
        }
    }

    return 0;
}

