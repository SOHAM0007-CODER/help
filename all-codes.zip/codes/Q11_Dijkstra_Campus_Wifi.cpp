#include <iostream>
#include <climits>
using namespace std;

int graph[101][101], dist[101], visited[101], parent[101];

// Dijkstra Algorithm
void dijkstra(int n, int source)
{
    for(int i = 0; i < n; i++)
    {
        dist[i] = INT_MAX;
        visited[i] = 0;
        parent[i] = -1;
    }

    dist[source] = 0;

    for(int i = 0; i < n - 1; i++)
    {
        int u = -1;

        for(int j = 0; j < n; j++)
            if(!visited[j] && (u == -1 || dist[j] < dist[u]))
                u = j;

        if(u == -1 || dist[u] == INT_MAX)
            break;

        visited[u] = 1;

        for(int v = 0; v < n; v++)
        {
            if(graph[u][v] > 0 && !visited[v] &&
               dist[u] + graph[u][v] < dist[v])
            {
                dist[v] = dist[u] + graph[u][v];
                parent[v] = u;
            }
        }
    }
}

// Display shortest paths to all departments
void display(int n, int source)
{
    cout << "\nMinimum Latency from Main Server:\n";

    for(int i = 0; i < n; i++)
    {
        cout << "\nDepartment Node " << i << " : ";

        if(dist[i] == INT_MAX)
        {
            cout << "Not reachable\n";
            continue;
        }

        cout << dist[i] << " ms";

        int path[101], count = 0;

        for(int v = i; v != -1; v = parent[v])
            path[count++] = v;

        cout << "\nRoute: ";

        for(int j = count - 1; j >= 0; j--)
        {
            cout << path[j];
            if(j > 0)
                cout << " -> ";
        }

        cout << endl;
    }
}

int main()
{
    int n, e;

    cout << "Enter number of routers: ";
    cin >> n;

    if(cin.fail() || n <= 0 || n > 100)
    {
        cout << "Invalid number of routers!";
        return 1;
    }

    cout << "Enter number of network connections: ";
    cin >> e;

    if(cin.fail() || e < 0 || e > 10000)
    {
        cout << "Invalid number of connections!";
        return 1;
    }

    cout << "\nEnter connections (Source Destination Latency):\n";

    for(int i = 0; i < e; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;

        if(cin.fail() || u < 0 || u >= n ||
           v < 0 || v >= n || u == v || w <= 0)
        {
            cout << "Invalid connection details!";
            return 1;
        }

        graph[u][v] = graph[v][u] = w;
    }

    int source;

    cout << "\nEnter main server location: ";
    cin >> source;

    if(cin.fail() || source < 0 || source >= n)
    {
        cout << "Invalid server location!";
        return 1;
    }

    // Before congestion update
    dijkstra(n, source);

    cout << "\n----- BEFORE NETWORK CONGESTION -----\n";
    display(n, source);

    // Ask for latency update
    char choice;

    cout << "\nDo you want to update network latency? (Y/N): ";
    cin >> choice;

    if(choice == 'Y' || choice == 'y')
    {
        int u, v, newTime;

        cout << "Enter affected connection (Source Destination): ";
        cin >> u >> v;

        if(cin.fail() || u < 0 || u >= n ||
           v < 0 || v >= n || graph[u][v] == 0)
        {
            cout << "Invalid connection!";
            return 1;
        }

        cout << "Enter new latency: ";
        cin >> newTime;

        if(cin.fail() || newTime <= 0)
        {
            cout << "Invalid latency!";
            return 1;
        }

        graph[u][v] = graph[v][u] = newTime;

        // Recalculate shortest paths
        dijkstra(n, source);

        cout << "\n----- AFTER NETWORK CONGESTION -----\n";
        display(n, source);
    }
    else if(choice == 'N' || choice == 'n')
    {
        cout << "\nNo network update required.\n";
    }
    else
    {
        cout << "Invalid choice!";
    }

    return 0;
}
