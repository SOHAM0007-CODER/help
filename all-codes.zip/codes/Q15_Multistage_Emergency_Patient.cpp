
#include <iostream>
#include <vector>
#include <climits>
using namespace std;

struct Edge
{
    int to;
    int weight;
};

vector<Edge> graph[20];

int stage[20];
int cost[20];
int path[20];

// Function to find minimum travel time
void shortestPath(int n, int stages, int source, int destination)
{
    // Initialize cost and path
    for(int i = 0; i < n; i++)
    {
        cost[i] = INT_MAX;
        path[i] = -1;
    }

    cost[destination] = 0;

    // Backward Dynamic Programming
    for(int s = stages - 2; s >= 0; s--)
    {
        for(int u = 0; u < n; u++)
        {
            if(stage[u] == s)
            {
                for(int j = 0; j < (int)graph[u].size(); j++)
                {
                    int v = graph[u][j].to;
                    int w = graph[u][j].weight;

                    if(cost[v] != INT_MAX)
                    {
                        int newCost = w + cost[v];

                        if(newCost < cost[u])
                        {
                            cost[u] = newCost;
                            path[u] = v;
                        }
                    }
                }
            }
        }
    }

    // Display optimal ambulance route
    if(cost[source] == INT_MAX)
    {
        cout << "\nNo ambulance route available!";
        return;
    }

    cout << "\nMinimum Ambulance Travel Time: "
         << cost[source] << " minutes";

    cout << "\nOptimal Ambulance Route: ";

    int current = source;

    while(current != -1)
    {
        cout << current;

        if(current == destination)
            break;

        cout << " -> ";
        current = path[current];
    }

    cout << endl;
}

int main()
{
    int n, stages, e;
    int source, destination;

    cout << "Enter number of locations (max 20): ";
    cin >> n;

    if(n < 2 || n > 20)
    {
        cout << "Invalid number of locations!";
        return 0;
    }

    cout << "Enter number of stages: ";
    cin >> stages;

    if(stages < 2 || stages > n)
    {
        cout << "Invalid number of stages!";
        return 0;
    }

    // Initialize stages
    for(int i = 0; i < n; i++)
    {
        stage[i] = -1;
    }

    // Assign locations to stages
    for(int s = 0; s < stages; s++)
    {
        int count, node;

        cout << "\nEnter number of locations in Stage "
             << s + 1 << ": ";

        cin >> count;

        if(count < 1 || count > n)
        {
            cout << "Invalid location count!";
            return 0;
        }

        cout << "Enter location numbers: ";

        for(int i = 0; i < count; i++)
        {
            cin >> node;

            if(node < 0 || node >= n || stage[node] != -1)
            {
                cout << "Invalid or repeated location!";
                return 0;
            }

            stage[node] = s;
        }
    }

    // Check all locations are assigned
    for(int i = 0; i < n; i++)
    {
        if(stage[i] == -1)
        {
            cout << "\nAll locations must be assigned to stages!";
            return 0;
        }
    }

    cout << "\nEnter number of roads: ";
    cin >> e;

    if(e < 1 || e > 400)
    {
        cout << "Invalid number of roads!";
        return 0;
    }

    // Input directed weighted roads
    cout << "\nEnter roads (Source Destination TravelTime):\n";

    for(int i = 0; i < e; i++)
    {
        int u, v, w;

        cin >> u >> v >> w;

        if(u < 0 || u >= n || v < 0 || v >= n ||
           w < 0 || stage[v] != stage[u] + 1)
        {
            cout << "Invalid road! Check locations, travel time and stages.";
            return 0;
        }

        // Store road (parallel roads are allowed)
        Edge newEdge;
        newEdge.to = v;
        newEdge.weight = w;

        graph[u].push_back(newEdge);
    }

    cout << "\nEnter source emergency station: ";
    cin >> source;

    cout << "Enter destination hospital: ";
    cin >> destination;

    if(source < 0 || source >= n ||
       destination < 0 || destination >= n ||
       stage[source] != 0 ||
       stage[destination] != stages - 1)
    {
        cout << "Invalid source or destination!";
        return 0;
    }

    // Find minimum travel time route
    shortestPath(n, stages, source, destination);

    return 0;
}

