
#include <iostream>
#include <climits>
using namespace std;

int graph[101][101], dist[101], visited[101], parent[101];

// Dijkstra Algorithm
void dijkstra(int n, int source)
{
    for(int i = 0; i < n; i++)
    {
        dist[i] = INT_MAX;
        visited[i] = 0;
        parent[i] = -1;
    }

    dist[source] = 0;

    for(int i = 0; i < n - 1; i++)
    {
        int u = -1;

        for(int j = 0; j < n; j++)
            if(!visited[j] && (u == -1 || dist[j] < dist[u]))
                u = j;

        if(u == -1 || dist[u] == INT_MAX)
            break;

        visited[u] = 1;

        for(int v = 0; v < n; v++)
        {
            if(graph[u][v] > 0 && !visited[v] &&
               dist[u] + graph[u][v] < dist[v])
            {
                dist[v] = dist[u] + graph[u][v];
                parent[v] = u;
            }
        }
    }
}

// Display shortest route
void display(int destination)
{
    if(dist[destination] == INT_MAX)
    {
        cout << "\nDestination is not reachable!\n";
        return;
    }

    cout << "\nDestination Airport: " << destination;
    cout << "\nShortest Travel Time: " << dist[destination] << " minutes";

    int path[101], count = 0;

    for(int v = destination; v != -1; v = parent[v])
        path[count++] = v;

    cout << "\nShortest Route: ";

    for(int i = count - 1; i >= 0; i--)
    {
        cout << path[i];
        if(i > 0)
            cout << " -> ";
    }

    cout << endl;
}

int main()
{
    int n, e;

    cout << "Enter number of airports: ";
    cin >> n;

    if(cin.fail() || n <= 0 || n > 100)
    {
        cout << "Invalid number of airports!";
        return 1;
    }

    cout << "Enter number of flights: ";
    cin >> e;

    if(cin.fail() || e < 0 || e > 10000)
    {
        cout << "Invalid number of flights!";
        return 1;
    }

    cout << "\nEnter flights (Source Destination TravelTime):\n";

    for(int i = 0; i < e; i++)
    {
        int u, v, w;
        cin >> u >> v >> w;

        if(cin.fail() || u < 0 || u >= n ||
           v < 0 || v >= n || u == v || w <= 0)
        {
            cout << "Invalid flight details!";
            return 1;
        }

        graph[u][v] = w;
    }

    int source, destination;

    cout << "\nEnter source airport: ";
    cin >> source;

    if(cin.fail() || source < 0 || source >= n)
    {
        cout << "Invalid source airport!";
        return 1;
    }

    cout << "Enter destination airport: ";
    cin >> destination;

    if(cin.fail() || destination < 0 || destination >= n ||
       destination == source)
    {
        cout << "Invalid destination airport!";
        return 1;
    }

    // Before delay update
    dijkstra(n, source);

    cout << "\n----- BEFORE FLIGHT DELAY -----\n";
    display(destination);

    // Ask for flight delay update
    char choice;

    cout << "\nDo you want to update flight travel time? (Y/N): ";
    cin >> choice;

    if(choice == 'Y' || choice == 'y')
    {
        int u, v, newTime;

        cout << "Enter affected flight (Source Destination): ";
        cin >> u >> v;

        if(cin.fail() || u < 0 || u >= n ||
           v < 0 || v >= n || graph[u][v] == 0)
        {
            cout << "Invalid flight!";
            return 1;
        }

        cout << "Enter new travel time: ";
        cin >> newTime;

        if(cin.fail() || newTime <= 0)
        {
            cout << "Invalid travel time!";
            return 1;
        }

        graph[u][v] = newTime;

        // Recalculate shortest route
        dijkstra(n, source);

        cout << "\n----- AFTER FLIGHT DELAY -----\n";
        display(destination);
    }
    else if(choice == 'N' || choice == 'n')
    {
        cout << "\nNo flight update required.\n";
    }
    else
    {
        cout << "Invalid choice!";
    }

    return 0;
}

