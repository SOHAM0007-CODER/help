#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

#define MAX_ORDERS 1000000

struct Transaction
{
    string transactionID;
    string productID;
    string productName;
    double price;
    string timestamp;
};

Transaction *arr = new Transaction[MAX_ORDERS];
Transaction *temp = new Transaction[MAX_ORDERS];
int n = 0;

// Merge Function - ascending order; equal keys keep their original order.
void merge(int low, int mid, int high)
{
    int i = low;
    int j = mid + 1;
    int k = low;

    while (i <= mid && j <= high)
    {
        if (arr[i].timestamp <= arr[j].timestamp)
            temp[k++] = arr[i++];
        else
            temp[k++] = arr[j++];
    }

    while (i <= mid)
        temp[k++] = arr[i++];

    while (j <= high)
        temp[k++] = arr[j++];

    for (i = low; i <= high; i++)
        arr[i] = temp[i];
}

// Merge Sort - same algorithm as your original code.
void mergeSort(int low, int high)
{
    if (low < high)
    {
        int mid = low + (high - low) / 2;
        mergeSort(low, mid);
        mergeSort(mid + 1, high);
        merge(low, mid, high);
    }
}

int main()
{

    ifstream file(
        "C:/Users/soham/Downloads/DAA DATASET/02_ecommerce_transactions.csv");

    if (!file)
    {
        cout << "File not found!\n";
        delete[] arr;
        delete[] temp;
        return 1;
    }

    string line;
    getline(file, line); // Skip header.

    while (n < MAX_ORDERS && getline(file, line))
    {
        if (!line.empty() && line.back() == '\r')
            line.pop_back();
        if (line.empty())
            continue;

        stringstream ss(line);
        string value;

        getline(ss, arr[n].transactionID, ',');
        getline(ss, arr[n].productID, ',');
        getline(ss, arr[n].productName, ',');
        getline(ss, value, ',');
        arr[n].price = stod(value);
        getline(ss, arr[n].timestamp);

        n++;
    }

    file.close();
    mergeSort(0, n - 1);

    cout << "\nE-commerce Transactions Sorted by Purchase Timestamp\n\n";
    cout << "transactionID\tproductID\tproductName\tprice\ttimestamp\n";


    for (int i = 0; i < n && i < 30; i++)
    {
        cout << arr[i].transactionID << "\t"
             << arr[i].productID << "\t"
             << arr[i].productName << "\t"
             << arr[i].price << "\t"
             << arr[i].timestamp << "\n";
    }

    delete[] arr;
    delete[] temp;
    return 0;
}
