
#include <iostream>
#include <string>
using namespace std;

int graph[20][20];
int color[20];
string course[20];

string colors[] = {
    "Red", "Blue", "Green", "Yellow", "Orange", "Brown", "White", "Black", "Gray", "Violet"
};

int n;

// Check whether a color can be assigned
bool isSafe(int node, int c)
{
    for(int i = 0; i < n; i++)
    {
        if(graph[node][i] == 1 && color[i] == c)
            return false;
    }

    return true;
}

// Graph Coloring using Backtracking
bool graphColoring(int node, int m)
{
    // All courses are colored
    if(node == n)
        return true;

    // Try available colors
    for(int c = 1; c <= m; c++)
    {
        if(isSafe(node, c))
        {
            color[node] = c;

            if(graphColoring(node + 1, m))
                return true;

            // Backtracking
            color[node] = 0;
        }
    }

    return false;
}

int main()
{
    int e;

    cout << "UNIVERSITY TIMETABLE SCHEDULING\n";

    cout << "\nEnter number of courses: ";
    cin >> n;

    if(n < 1 || n > 20)
    {
        cout << "Invalid number of courses!";
        return 0;
    }

    // Initialize graph and colors
    for(int i = 0; i < n; i++)
    {
        color[i] = 0;

        for(int j = 0; j < n; j++)
            graph[i][j] = 0;
    }

    // Input course names
    cout << "\nEnter course names:\n";

    for(int i = 0; i < n; i++)
    {
        cout << "Course " << i + 1 << ": ";
        cin >> course[i];
    }

    // Input conflicts
    cout << "\nEnter number of conflicting course pairs: ";
    cin >> e;

    if(e < 0 || e > n * (n - 1) / 2)
    {
        cout << "Invalid number of conflicts!";
        return 0;
    }

    cout << "\nEnter conflicting course pairs:\n";

    for(int i = 0; i < e; i++)
    {
        int u, v;
        cin >> u >> v;

        if(u < 1 || u > n || v < 1 || v > n || u == v)
        {
            cout << "Invalid course IDs!";
            return 0;
        }

        u--;
        v--;

        graph[u][v] = 1;
        graph[v][u] = 1;
    }

    // Display conflict table
    cout << "\nCONFLICT TABLE\n";
    cout << "Course | Conflicting courses\n";

    for(int i = 0; i < n; i++)
    {
        cout << course[i] << " | ";

        for(int j = 0; j < n; j++)
        {
            if(graph[i][j] == 1)
                cout << course[j] << " ";
        }

        cout << endl;
    }

    // Find minimum number of colors
    int m;

    for(m = 1; m <= n; m++)
    {
        for(int i = 0; i < n; i++)
            color[i] = 0;

        if(graphColoring(0, m))
            break;
    }

    // Display color assignment
    cout << "\nEXAM COLOR ASSIGNMENT\n";
    cout << "Course | Assigned Color\n";

    for(int i = 0; i < n; i++)
    {
        cout << course[i] << " | "
             << colors[color[i] - 1] << endl;
    }

    // Display exams grouped by color
    cout << "\nEXAMS GROUPED BY COLOR\n";

    for(int c = 1; c <= m; c++)
    {
        cout << colors[c - 1] << " (Slot " << c << "): ";

        for(int i = 0; i < n; i++)
        {
            if(color[i] == c)
                cout << course[i] << " ";
        }

        cout << endl;
    }

    // Scheduling summary
    cout << "\nSCHEDULING SUMMARY\n";
    cout << "Total Courses: " << n << endl;
    cout << "Total Conflicts: " << e << endl;
    cout << "Minimum Colors Used: " << m << endl;

    return 0;
}

