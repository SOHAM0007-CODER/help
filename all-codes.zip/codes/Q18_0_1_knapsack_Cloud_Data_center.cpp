
#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

struct Task
{
    string name;
    int weight, utility;
    bool selected;
};

int main()
{
    int N, W;

    cout << "CLOUD DATA CENTER RESOURCE ALLOCATION\n";

    cout << "Enter number of tasks: ";
    cin >> N;

    if (!cin || N <= 0)
    {
        cout << "Invalid number of tasks.\n";
        return 0;
    }

    vector<Task> tasks(N);

    cout << "\nEnter task details: Name Resource_Required Utility\n";

    for (int i = 0; i < N; i++)
    {
        cout << "Task " << i + 1 << ": ";

        cin >> tasks[i].name
            >> tasks[i].weight
            >> tasks[i].utility;

        if (!cin || tasks[i].weight <= 0 ||
            tasks[i].utility < 0)
        {
            cout << "Invalid task details.\n";
            return 0;
        }

        tasks[i].selected = false;
    }

    // Display task inventory
    cout << "\nTASK INVENTORY:\n";

    cout << left << setw(20) << "Task"
         << setw(20) << "Resources"
         << setw(15) << "Utility" << "\n";

    for (int i = 0; i < N; i++)
    {
        cout << left << setw(20) << tasks[i].name
             << setw(20) << tasks[i].weight
             << setw(15) << tasks[i].utility << "\n";
    }

    cout << "\nEnter server resource capacity: ";
    cin >> W;

    if (!cin || W < 0)
    {
        cout << "Invalid server capacity.\n";
        return 0;
    }

    // Dynamic Programming table
    vector<vector<int> > dp(
        N + 1, vector<int>(W + 1, 0)
    );

    for (int i = 1; i <= N; i++)
    {
        for (int w = 0; w <= W; w++)
        {
            // Exclude current task
            dp[i][w] = dp[i - 1][w];

            // Include current task if capacity allows
            if (tasks[i - 1].weight <= w)
            {
                int newUtility =
                    tasks[i - 1].utility +
                    dp[i - 1][w - tasks[i - 1].weight];

                if (newUtility > dp[i][w])
                {
                    dp[i][w] = newUtility;
                }
            }
        }
    }

    // Backtracking to find selected tasks
    int remainingCapacity = W;

    for (int i = N; i >= 1; i--)
    {
        if (dp[i][remainingCapacity] !=
            dp[i - 1][remainingCapacity])
        {
            tasks[i - 1].selected = true;

            remainingCapacity -= tasks[i - 1].weight;
        }
    }

    // Display selected tasks
    int totalResources = 0;
    int totalUtility = 0;
    int count = 0;

    cout << "\nSELECTED TASKS:\n";

    cout << left << setw(20) << "Task"
         << setw(20) << "Resources"
         << setw(15) << "Utility" << "\n";

    for (int i = 0; i < N; i++)
    {
        if (tasks[i].selected)
        {
            cout << left << setw(20) << tasks[i].name
                 << setw(20) << tasks[i].weight
                 << setw(15) << tasks[i].utility << "\n";

            totalResources += tasks[i].weight;
            totalUtility += tasks[i].utility;
            count++;
        }
    }

    if (count == 0)
        cout << "No tasks selected.\n";

    // Final allocation summary
    cout << "\nFINAL ALLOCATION SUMMARY:\n";

    cout << "Server Capacity     : " << W << "\n";
    cout << "Resources Allocated : " << totalResources << "\n";
    cout << "Remaining Resources : "
         << W - totalResources << "\n";
    cout << "Tasks Selected      : " << count << "\n";
    cout << "Maximum Utility     : " << dp[N][W] << "\n";

    cout << "\nREJECTED TASKS:\n";

    for (int i = 0; i < N; i++)
    {
        if (!tasks[i].selected)
        {
            cout << tasks[i].name
                 << " - Resources: " << tasks[i].weight
                 << ", Utility: " << tasks[i].utility
                 << "\n";
        }
    }
    return 0;
}

